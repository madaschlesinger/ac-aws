package com.adaptive.cloud.config.file;

import com.adaptive.cloud.config.ConfigNode;
import com.adaptive.cloud.config.Property;
import com.google.common.collect.ImmutableList;

import java.util.*;

/**
 * Represents a node of the configuration hierarchy.
 * <p>
 * Offers support for resolving placeholders in the property values. See {@link PlaceholderResolver}.
 * </p>
 * @author Spencer Ward
 */
class ConfigNodeImpl implements ConfigNode {
    private final PlaceholderResolver resolver;
    private final String name;
    private final String value;
    private final ConfigNode parent;
    private final Map<String, ConfigNodeImpl> children;

    private ConfigNodeImpl(String name, ConfigNode parent, String value, PlaceholderResolver resolver) {
        this.name = name;
        this.parent = parent;
        this.value = value;
        this.resolver = resolver;
        this.children = new HashMap<>();
    }

    /**
     * Create a root config node with neither children nor properties.
     * @param resolver the mechanism for resolving properties.  The resolver will also be made aware of this config node to
     *                 allow other nodes to access this properties in this node
     * @return the root node of a config hierarchy
     */
    static ConfigNodeImpl createRoot(PlaceholderResolver resolver) {
        return new ConfigNodeImpl(null, null, null, resolver);
    }

    /**
     * Add a child node to the hierarchy
     * @param node the node name (this should be a DIRECT child, NOT a path to a descendant node)
     * @return the new child node
     */
    ConfigNodeImpl addChild(String node, String value) {
        if (!children.containsKey(node)) {
            ConfigNodeImpl child = new ConfigNodeImpl(node, this, value, resolver);
            children.put(node, child);
        }
        return children.get(node);
    }

    /**
     * Add a property to this node.  The property value will be provided as a string, but may represent a different datatype.
     * The property is added by path name, which may be a simple name, or a dot separated path ending in the property name.
     * @param path the path name of the property
     * @param value the string representation of the property value
     */
    void addProperty(String path, String value) {
        String[] pathParts = path.split("\\.", 2);

        if (pathParts.length < 2) {
            addChild(pathParts[0], value);
        } else {
            addChild(pathParts[0], null).addProperty(pathParts[1], value);
        }
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public ConfigNode parent() {
        return parent;
    }

    @Override
    public Collection<ConfigNode> children() {
        return ImmutableList.<ConfigNode>copyOf(children.values());
    }

    @Override
    public ConfigNode child(String name) {
        return children.get(name);
    }

    @Override
    public Collection<Property> properties() {
        List<Property> properties = new ArrayList<>();
        addProperties("", properties);
        return properties;
    }

    @Override
    public Property property(String path) {
        String[] pathParts = path.split("\\.", 2);

        if (pathParts.length < 2) {
            ConfigNodeImpl propertyNode = children.get(path);
            return propertyNode == null ? null : new StringProperty(path, propertyNode.value, this, resolver);
        } else {
            ConfigNode child = child(pathParts[0]);
            return child == null ? null : child.property(pathParts[1]);
        }
    }

    private void addProperties(String prefix, List<Property> properties) {
        for (ConfigNodeImpl child : children.values()) {
            if (child.value != null) {
                properties.add(new StringProperty(prefix + name, child.value, this, resolver));
            }
            child.addProperties(child.name() + ".", properties);
        }
    }
}
